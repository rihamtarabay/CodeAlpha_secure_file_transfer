import os
import sqlite3
from cryptography.fernet import Fernet
import paramiko
import hashlib
from getpass import getpass

# Generate a key for encryption
def generate_key():
    return Fernet.generate_key()

# Encrypt a file
def encrypt_file(key, file_path):
    fernet = Fernet(key)
    with open(file_path, 'rb') as file:
        original = file.read()
    encrypted = fernet.encrypt(original)
    with open(file_path, 'wb') as encrypted_file:
        encrypted_file.write(encrypted)

# Decrypt a file
def decrypt_file(key, file_path):
    fernet = Fernet(key)
    with open(file_path, 'rb') as enc_file:
        encrypted = enc_file.read()
    decrypted = fernet.decrypt(encrypted)
    with open(file_path, 'wb') as dec_file:
        dec_file.write(decrypted)

# Compute SHA-256 hash of a file
def compute_hash(file_path):
    sha256_hash = hashlib.sha256()
    with open(file_path, "rb") as f:
        for byte_block in iter(lambda: f.read(4096), b""):
            sha256_hash.update(byte_block)
    return sha256_hash.hexdigest()

# Establish SSH connection and transfer file
def secure_file_transfer(host, port, username, password, local_file, remote_file):
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    ssh.connect(host, port, username, password)
    
    sftp = ssh.open_sftp()
    sftp.put(local_file, remote_file)
    sftp.close()
    ssh.close()

# Log file transfer details to the database
def log_transfer(user_id, file_name, transfer_status):
    conn = sqlite3.connect('audit_logs.db')
    cursor = conn.cursor()
    cursor.execute('''CREATE TABLE IF NOT EXISTS logs
                      (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id TEXT, file_name TEXT, transfer_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP, transfer_status TEXT)''')
    cursor.execute('INSERT INTO logs (user_id, file_name, transfer_status) VALUES (?, ?, ?)', (user_id, file_name, transfer_status))
    conn.commit()
    conn.close()

# Main function
def main():
    # User inputs
    user_id = input("Enter your user ID: ")
    password = getpass("Enter your password: ")
    local_file = input("Enter the path to the file to be transferred: ")
    remote_file = input("Enter the remote file path: ")
    
    # Generate encryption key
    key = generate_key()
    
    # Encrypt the file
    encrypt_file(key, local_file)
    
    # Compute file hash before transfer
    original_hash = compute_hash(local_file)
    
    # Perform secure file transfer
    try:
        secure_file_transfer('remote_host', 22, 'username', password, local_file, remote_file)
        transfer_status = "Success"
    except Exception as e:
        transfer_status = f"Failed: {e}"
    
    # Decrypt the file
    decrypt_file(key, local_file)
    
    # Compute file hash after transfer and verify integrity
    transferred_hash = compute_hash(local_file)
    if original_hash == transferred_hash:
        print("File integrity verified.")
    else:
        print("File integrity check failed.")
        transfer_status = "Integrity Check Failed"
    
    # Log the transfer
    log_transfer(user_id, local_file, transfer_status)
    
    print("File transfer completed.")

if __name__ == "__main__":
    main()
